#!/bin/bash
set -euo pipefail
SOURCE=$(cd "$(dirname "$0")/.." && pwd)
KDIR=${KDIR:-/opt/ddk/kdir/android14-6.1}
CLANG=${CLANG:-/opt/ddk/clang/clang-r487747c/bin}
RELEASE=6.1.162-android14-11-34343818-abF956BXXU4EZIH
printf '%s\n' "$RELEASE" > "$KDIR/include/config/kernel.release"
printf '#define UTS_RELEASE "%s"\n' "$RELEASE" > "$KDIR/include/generated/utsrelease.h"
export PATH="$STAGE/tools/usr/bin:$CLANG:$PATH"
export LD_LIBRARY_PATH="$STAGE/tools/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
"$CLANG/clang" --version
make -C "$KDIR" M="$SOURCE/kernel" \
    ARCH=arm64 LLVM=1 LLVM_IAS=1 KBUILD_MODPOST_WARN=1 \
    CONFIG_KSU=m KSU_GIT_VERSION_VALID=1 KSU_GIT_VERSION=3294 KSU_GIT_TAG=v3.4.0 \
    CONFIG_KSU_SAMSUNG_KDP=y CONFIG_KSU_SAMSUNG_RKP=y \
    CONFIG_KSU_SAMSUNG_DEFEX=y CONFIG_KSU_SAMSUNG_NO_PATCH_TEXT=y \
    modules -j"$(nproc)"

mkdir -p "$SOURCE/artifacts"
cp "$SOURCE/kernel/kernelsu.ko" "$SOURCE/artifacts/kernelsu-unstripped.ko"
"$CLANG/llvm-strip" --strip-debug "$SOURCE/kernel/kernelsu.ko"
cp "$SOURCE/kernel/kernelsu.ko" "$SOURCE/artifacts/kernelsu.ko"
