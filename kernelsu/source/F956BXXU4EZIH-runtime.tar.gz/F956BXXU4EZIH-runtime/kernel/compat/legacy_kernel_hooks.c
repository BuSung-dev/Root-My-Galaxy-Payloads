#include <linux/fs.h>
#include <linux/types.h>
#include <linux/uaccess.h>

#include "uapi/supercall.h"
#include "supercall/supercall.h"
#include "util.h"

/*
 * The vendor 4.9 tree calls this hook directly from reboot(2).  The
 * userspace driver probe uses the same magic pair to request the KernelSU
 * anon-inode descriptor, so this compatibility entry point must install the
 * real descriptor rather than being a link-only stub.
 */
int ksu_handle_sys_reboot(int magic1, int magic2, unsigned int cmd,
                          void __user **arg)
{
    (void)cmd;

    if ((unsigned int)magic1 != KSU_INSTALL_MAGIC1 ||
        (unsigned int)magic2 != KSU_INSTALL_MAGIC2)
        return 0;

    int fd = ksu_install_fd();
    if (fd < 0)
        return 0;

    if (!arg || copy_to_user((void __user *)*arg, &fd, sizeof(fd)))
        ksu_close_fd(fd);

    return 0;
}

int ksu_handle_devpts(struct inode *inode)
{
    (void)inode;
    return 0;
}
