#include <linux/mm.h>
#include <linux/errno.h>
#include <linux/kallsyms.h>
#include <linux/printk.h>
#include <linux/uaccess.h>

#define KSU_4_19_TRAMPOLINE(name)                                             \
    void *ksu_compat_fn_##name;                                               \
    asm(".pushsection .text\n"                                                \
        ".global " #name "\n"                                               \
        ".type " #name ", %function\n"                                      \
        #name ":\n"                                                          \
        "adrp x16, ksu_compat_fn_" #name "\n"                               \
        "ldr x16, [x16, :lo12:ksu_compat_fn_" #name "]\n"                   \
        "br x16\n"                                                           \
        ".size " #name ", .-" #name "\n"                                   \
        ".popsection\n");

KSU_4_19_TRAMPOLINE(__arm64_sys_setns)
KSU_4_19_TRAMPOLINE(alloc_uid)
KSU_4_19_TRAMPOLINE(avc_ss_reset)
KSU_4_19_TRAMPOLINE(avtab_insert_nonunique)
KSU_4_19_TRAMPOLINE(avtab_search_node)
KSU_4_19_TRAMPOLINE(avtab_search_node_next)
KSU_4_19_TRAMPOLINE(change_pid)
KSU_4_19_TRAMPOLINE(do_mount)
KSU_4_19_TRAMPOLINE(ebitmap_get_bit)
KSU_4_19_TRAMPOLINE(ebitmap_set_bit)
KSU_4_19_TRAMPOLINE(ext4_unregister_sysfs)
KSU_4_19_TRAMPOLINE(find_task_by_vpid)
KSU_4_19_TRAMPOLINE(free_uid)
KSU_4_19_TRAMPOLINE(fsnotify_add_mark)
KSU_4_19_TRAMPOLINE(fsnotify_alloc_group)
KSU_4_19_TRAMPOLINE(fsnotify_destroy_mark)
KSU_4_19_TRAMPOLINE(fsnotify_init_mark)
KSU_4_19_TRAMPOLINE(fsnotify_put_group)
KSU_4_19_TRAMPOLINE(fsnotify_put_mark)
KSU_4_19_TRAMPOLINE(get_task_cred)
KSU_4_19_TRAMPOLINE(hashtab_insert)
KSU_4_19_TRAMPOLINE(hashtab_search)
KSU_4_19_TRAMPOLINE(ksys_umount)
KSU_4_19_TRAMPOLINE(ksys_unshare)
KSU_4_19_TRAMPOLINE(ns_get_path)
KSU_4_19_TRAMPOLINE(put_seccomp_filter)
KSU_4_19_TRAMPOLINE(selinux_status_update_policyload)
KSU_4_19_TRAMPOLINE(selnl_notify_policyload)
KSU_4_19_TRAMPOLINE(task_work_add)

void *ksu_compat_selinux_state_4_19;
void *ksu_compat_mntns_operations_4_19;
void *ksu_compat_tasklist_lock_4_19;
void *ksu_compat_uts_sem_4_19;

#define KSU_RESOLVE_4_19(name)                                                \
    do {                                                                      \
        ksu_compat_fn_##name = (void *)kallsyms_lookup_name(#name);           \
        if (!ksu_compat_fn_##name) {                                          \
            pr_err("4.19 compatibility symbol unavailable: %s\n", #name);   \
            return -ENOENT;                                                   \
        }                                                                     \
    } while (0)

int ksu_compat_4_19_init(void)
{
    KSU_RESOLVE_4_19(__arm64_sys_setns);
    KSU_RESOLVE_4_19(alloc_uid);
    KSU_RESOLVE_4_19(avc_ss_reset);
    KSU_RESOLVE_4_19(avtab_insert_nonunique);
    KSU_RESOLVE_4_19(avtab_search_node);
    KSU_RESOLVE_4_19(avtab_search_node_next);
    KSU_RESOLVE_4_19(change_pid);
    KSU_RESOLVE_4_19(do_mount);
    KSU_RESOLVE_4_19(ebitmap_get_bit);
    KSU_RESOLVE_4_19(ebitmap_set_bit);
    KSU_RESOLVE_4_19(ext4_unregister_sysfs);
    KSU_RESOLVE_4_19(find_task_by_vpid);
    KSU_RESOLVE_4_19(free_uid);
    KSU_RESOLVE_4_19(fsnotify_add_mark);
    KSU_RESOLVE_4_19(fsnotify_alloc_group);
    KSU_RESOLVE_4_19(fsnotify_destroy_mark);
    KSU_RESOLVE_4_19(fsnotify_init_mark);
    KSU_RESOLVE_4_19(fsnotify_put_group);
    KSU_RESOLVE_4_19(fsnotify_put_mark);
    KSU_RESOLVE_4_19(get_task_cred);
    KSU_RESOLVE_4_19(hashtab_insert);
    KSU_RESOLVE_4_19(hashtab_search);
    KSU_RESOLVE_4_19(ksys_umount);
    KSU_RESOLVE_4_19(ksys_unshare);
    KSU_RESOLVE_4_19(ns_get_path);
    KSU_RESOLVE_4_19(put_seccomp_filter);
    KSU_RESOLVE_4_19(selinux_status_update_policyload);
    KSU_RESOLVE_4_19(selnl_notify_policyload);
    KSU_RESOLVE_4_19(task_work_add);

#define KSU_RESOLVE_DATA_4_19(dst, name)                                      \
    do {                                                                      \
        dst = (void *)kallsyms_lookup_name(name);                             \
        if (!dst) {                                                           \
            pr_err("4.19 compatibility data unavailable: %s\n", name);      \
            return -ENOENT;                                                   \
        }                                                                     \
    } while (0)

    KSU_RESOLVE_DATA_4_19(ksu_compat_selinux_state_4_19, "selinux_state");
    KSU_RESOLVE_DATA_4_19(ksu_compat_mntns_operations_4_19, "mntns_operations");
    KSU_RESOLVE_DATA_4_19(ksu_compat_tasklist_lock_4_19, "tasklist_lock");
    KSU_RESOLVE_DATA_4_19(ksu_compat_uts_sem_4_19, "uts_sem");

    pr_info("Linux 4.19 private ABI compatibility initialized\n");
    return 0;
}

long copy_from_user_nofault(void *dst, const void __user *src, size_t size)
{
    unsigned long ret = size;

    if (access_ok(VERIFY_READ, src, size)) {
        pagefault_disable();
        ret = __copy_from_user_inatomic(dst, src, size);
        pagefault_enable();
    }
    return ret ? -EFAULT : 0;
}

long copy_to_user_nofault(void __user *dst, const void *src, size_t size)
{
    unsigned long ret = size;

    if (access_ok(VERIFY_WRITE, dst, size)) {
        pagefault_disable();
        ret = __copy_to_user_inatomic(dst, src, size);
        pagefault_enable();
    }
    return ret ? -EFAULT : 0;
}

long strncpy_from_user_nofault(char *dst, const void __user *src, long count)
{
    mm_segment_t old_fs;
    long ret;

    if (count <= 0)
        return 0;

    old_fs = get_fs();
    set_fs(USER_DS);
    pagefault_disable();
    ret = strncpy_from_user(dst, src, count);
    pagefault_enable();
    set_fs(old_fs);

    if (ret >= count) {
        ret = count;
        dst[count - 1] = '\0';
    } else if (ret > 0) {
        ret++;
    }
    return ret;
}
