#ifndef __KSU_COMPAT_4_19_H
#define __KSU_COMPAT_4_19_H

#include <linux/string.h>
#include <linux/types.h>
#include <linux/compiler_types.h>

#ifndef TWA_RESUME
#define TWA_RESUME true
#endif

#ifndef fallthrough
#define fallthrough do { } while (0)
#endif

long strncpy_from_user_nofault(char *dst, const void __user *src, long count);
long copy_from_user_nofault(void *dst, const void __user *src, size_t size);
long copy_to_user_nofault(void __user *dst, const void *src, size_t size);

int ksu_compat_4_19_init(void);
extern void *ksu_compat_selinux_state_4_19;
extern void *ksu_compat_mntns_operations_4_19;
extern void *ksu_compat_tasklist_lock_4_19;
extern void *ksu_compat_uts_sem_4_19;

static inline ssize_t ksu_strscpy_pad_4_19(char *dst, const char *src,
                                           size_t count)
{
    ssize_t written = strscpy(dst, src, count);

    if (written >= 0 && (size_t)written + 1 < count)
        memset(dst + written + 1, 0, count - (size_t)written - 1);
    return written;
}

#define strscpy_pad ksu_strscpy_pad_4_19

#endif
