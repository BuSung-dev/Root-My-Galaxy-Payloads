#include <linux/init.h>

#include "feature/selinux_hide.h"
#include "klog.h"

/*
 * The SELinux status/policy mirroring implementation depends on the 5.10+
 * selinux_state layout. Keep the optional concealment feature disabled on
 * Samsung 4.19; normal KernelSU policy injection remains available.
 */
void __init ksu_selinux_hide_init(void)
{
    pr_info("selinux_hide is unavailable on Linux 4.19\n");
}

void __exit ksu_selinux_hide_exit(void)
{
}

void ksu_selinux_hide_drop_backup_if_unused(void)
{
}

void ksu_selinux_hide_handle_second_stage(void)
{
}

void ksu_selinux_hide_handle_post_fs_data(void)
{
}
