# EZIH runtime source

This tree is the source used for the firmware-specific KernelSU Next daemon
and module distributed with the SM-F956B F956BXXU4EZIH shell profile. It is
based on KernelSU Next commit `1a879d6a866f80b1fa1c1009a2ffa747873cbb5e`.

The kernel driver uses GPL-2.0-only. The userspace code uses GPL-3.0-or-later.
The original notices and license files are included. This archive contains
the runtime source, not the PomPomSU manager.

## Kernel module

Use a prepared Android 14 / Linux 6.1 DDK tree with Android clang r487747c.
Set `KDIR` and `CLANG` to the corresponding kernel build directory and compiler
directory, then run `bash scripts/build-module.sh`. The script builds for the
full EZIH kernel release and enables the Samsung KDP, RKP, DEFEX and
NO_PATCH_TEXT settings.

The distributed module was audited against the symbols and BTF from the
exact EZIH boot image. A module build with a different prepared kernel tree
must repeat those checks; changing its release string does not establish ABI
compatibility.

## Daemon

Place the audited module at
`userspace/ksud/bin/aarch64/samsung-F956BXXU4EZIH-6.1.162_kernelsu.ko`.
This snapshot includes the audited module that was embedded in the daemon.
Use Rust and Android NDK 29.0.14206865 with the
`aarch64-linux-android26-clang` target. Configure the Cargo linker and bindgen
sysroot for that toolchain, then run:

```sh
cargo build --release --target aarch64-linux-android --locked --manifest-path userspace/ksud/Cargo.toml
```

The output is `target/aarch64-linux-android/release/ksud`. It includes the
firmware module and checks the exact EZIH kernel release before late-load.
